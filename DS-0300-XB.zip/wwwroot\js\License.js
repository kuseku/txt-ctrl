﻿(function () {
	"use strict";

	var btnGetLicenseReqStr, btnUnregister, btnRegister, btnRenew, btnRegMan,
		areaLicStrManual, btnUnregisterOffline;

	/**
	 * Enters the lciense request string into the textarea
	 * @param {string} licenseRequestString
	 */
	function showLicenseRequestString(licenseRequestString) {
		setInputValidity(true, "txtSerialOffline");
		var areaLicReqStr = document.getElementById("areaLicReqStr");
		areaLicReqStr.value = licenseRequestString;
	}

	function setInputValidity(isValid, inputElementName) {
		var input = document.getElementById(inputElementName);
		if (isValid) {
			input.classList.remove("is-invalid");
		}
		else {
			input.classList.add("is-invalid");
		}
	}

	/**
	 * Shows the reason for the serial string being invalid in red under one of the serial string input elements
	 * @param {string} invalidText The text to display
	 * @param {string} regType Registration type ("Online" or "Offline")
	 */
	function showInvalidSerialText(invalidText, regType) {
		var invalidFeedback = document.getElementById("txtSerial" + regType + "_invalidFeedback");
		invalidFeedback.textContent = invalidText;
		setInputValidity(false, "txtSerial" + regType);
	}

	/**
	 * Validates a serial string.
	 * @param {string} serial The serial string to validate.
	 * @param {string} regType Registration type ("Online" or "Offline")
	 * @param {string} successCallback Callback function which is called in case of a valid serial string.
	 * @param {string} errorCallback Callback function which is called in case of an invalid serial string with 
	 *		an error text as a single parameter.
	 */
	function validateSerialString(serial, regType, successCallback, errorCallback) {
		var xhr = new XMLHttpRequest();
		xhr.addEventListener("load", transferComplete);
		xhr.addEventListener("error", function () {
			throw new Error("Serial string validation request failed.");
		});

		xhr.open("GET", "License/ValidateSerialString?serial=" + encodeURIComponent(serial));
		xhr.send();

		function transferComplete() {
			switch (xhr.status) {
				case 200:
					successCallback();
					break;

				case 400:
					showInvalidSerialText(xhr.responseText, regType);
					errorCallback(xhr.responseText);
					break;

				default:
					console.error("Serial string validation request failed. Unexpected response code " + xhr.status + ".");
					break;
			}
		}
	}

	/**
	 * Sends a http GET request to the license/requeststring controller.
	 * @param {string} serial - The serial number / string.
	 */
	function getLicenseRequestString(serial) {
		var xhr = new XMLHttpRequest();

		// Validate serial string before requesting the license request string
		validateSerialString(serial, "Offline",
			function () {
				xhr.addEventListener("load", transferComplete);
				xhr.addEventListener("error", function () {
					throw new Error("License request string request failed.");
				});
			
				xhr.open("GET", "License/RequestString?serial=" + encodeURIComponent(serial));
				xhr.send();
			},
			function () { btnGetLicenseReqStr.disabled = false; });

		function transferComplete() {
			btnGetLicenseReqStr.disabled = false;
			switch (xhr.status) {
				case 200:
					showLicenseRequestString(xhr.responseText);
					break;

				case 400:
					showInvalidSerialText(xhr.responseText, "Offline");
					break;

				default:
					console.error("License request string request failed. Unexpected response code " + xhr.status + ".");
					break;
			}
		}
	}

	function areaLicStrManual_change() {
		var disabled = (areaLicStrManual.value.trim() === "");
		btnRegMan.disabled = disabled;
	}

	/**
	 * "Request License string" button event handler.
	 */
	function btnGetLicensReqStr_click() {
		// Prevent multiple clicks
		btnGetLicenseReqStr.disabled = true;
		// Clear current license request string
		var areaLicReqStr = document.getElementById("areaLicReqStr");
		areaLicReqStr.value = "";
		// Send request
		var txtSerialOffline = document.getElementById("txtSerialOffline");
		getLicenseRequestString(txtSerialOffline.value.trim());
	}

	function btnRegMan_click() {
		// Prevent multiple clicks
		btnRegMan.disabled = true;
		var license = areaLicStrManual.value.trim();

		var xhr = new XMLHttpRequest();
		xhr.addEventListener("load", transferComplete);
		xhr.addEventListener("error", function () {
			throw new Error("Manual registration request failed.");
		});
		xhr.open("POST", "License/Register");
		xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
		xhr.send(JSON.stringify({ licenseString: license }));

		function transferComplete() {
			btnRegMan.disabled = false;
			switch (xhr.status) {
				case 200:
					location.reload();
					break;

				case 400:
					console.error(xhr.responseText);
					showFailAlert(xhr.responseText);
					break;

				default:
					console.error("Manual registration request failed. Unexpected response code " + xhr.status + ".");
					break;
			}
		}
	}

	function btnRegister_click() {
		var serial = txtSerialOnline.value.trim();

		// Prevent multiple clicks
		btnRegister.disabled = true;

		var xhr = new XMLHttpRequest();

		validateSerialString(serial, "Online",
			function () {
				xhr.addEventListener("load", transferComplete);
				xhr.addEventListener("error", function () {
					throw new Error("Registration request failed.");
				});
				xhr.open("GET", "License/RegisterOnline?serial=" + encodeURIComponent(serial));
				xhr.send();
			},
			function () { btnRegister.disabled = false; });

		function transferComplete() {
			btnRegister.disabled = false;
			switch (xhr.status) {
				case 200:
					location.reload();
					break;

				case 400:
					console.error(xhr.responseText);
					showFailAlert(xhr.responseText);
					break;

				default:
					console.error("Registration request failed. Unexpected response code " + xhr.status + ".");
					break;
			}
		}
	}

	function btnRenew_click() {
		/** @type {ConfirmationDialogOptions} */
		var confOpts = {
			text: StringResources.VIEW_LICENSE_RENEW_QUESTION,
			title: StringResources.VIEW_LICENSE_TITLE,
			okButtonText: StringResources.BTN_RENEW,
			cancelButtonText: StringResources.BTN_CANCEL,
			isDanger: false
		};
		confirmFancy(confOpts, function () {
			var serial = txtSerialOnline.value.trim();

			// Prevent multiple clicks
			btnRenew.disabled = true;

			var xhr = new XMLHttpRequest();

			validateSerialString(serial, "Online",
				function () {
					xhr.addEventListener("load", transferComplete);
					xhr.addEventListener("error", function () {
						throw new Error("Renewal request failed.");
					});
					xhr.open("GET", "License/RenewOnline?serial=" + encodeURIComponent(serial));
					xhr.send();
				},
				function () { btnRenew.disabled = false; });

			function transferComplete() {
				btnRenew.disabled = false;
				switch (xhr.status) {
					case 200:
						location.reload();
						break;

					case 400:
						console.error(xhr.responseText);
						showFailAlert(xhr.responseText);
						break;

					default:
						console.error("Renewal request failed. Unexpected response code " + xhr.status + ".");
						break;
				}
			}
		});
	}

	function btnUnregister_click() {
		/** @type {ConfirmationDialogOptions} */
		var confOpts = {
			text: StringResources.VIEW_LICENSE_UNREGISTER_QUESTION,
			title: StringResources.VIEW_LICENSE_TITLE,
			okButtonText: StringResources.BTN_UNREGISTER,
			cancelButtonText: StringResources.BTN_CANCEL,
			isDanger: true
		};
		confirmFancy(confOpts, function () {
			var serial = txtSerialOnline.value.trim();

			// Prevent multiple clicks
			btnUnregister.disabled = true;

			var xhr = new XMLHttpRequest();
			validateSerialString(serial, "Online",
				function () {
					xhr.addEventListener("load", transferComplete);
					xhr.addEventListener("error", function () {
						throw new Error("Registration request failed.");
					});
					xhr.open("GET", "License/UnregisterOnline?serial=" + encodeURIComponent(serial));
					xhr.send();
				},
				function () { btnUnregister.disabled = false; });

			function transferComplete() {
				btnUnregister.disabled = false;
				switch (xhr.status) {
					case 200:
						location.reload();
						break;

					case 400:
						console.error(xhr.responseText);
						showFailAlert(xhr.responseText);
						break;

					default:
						console.error("Un-Registration request failed. Unexpected response code " + xhr.status + ".");
						break;
				}
			}
		});
	}

	function btnUnregisterOffline_click() {
		/** @type {ConfirmationDialogOptions} */
		var confOpts = {
			text: StringResources.VIEW_LICENSE_UNREGISTER_MANUALLY_QUESTION,
			title: StringResources.VIEW_LICENSE_TITLE,
			okButtonText: StringResources.BTN_UNREGISTER,
			cancelButtonText: StringResources.BTN_CANCEL,
			isDanger: true
		};
		confirmFancy(confOpts, function () {
			// Prevent multiple clicks
			btnUnregister.disabled = true;

			var xhr = new XMLHttpRequest();
			xhr.addEventListener("load", transferComplete);
			xhr.addEventListener("error", function () {
				throw new Error("Unregistration request failed.");
			});
			xhr.open("GET", "License/Unregister");
			xhr.send();

			function transferComplete() {
				btnUnregister.disabled = false;
				switch (xhr.status) {
					case 200:
						location.reload();
						break;

					case 400:
						console.error(xhr.responseText);
						showFailAlert(xhr.responseText);
						break;

					default:
						console.error("Un-Registration request failed. Unexpected response code " + xhr.status + ".");
						break;
				}
			}
		});
	}

	function copyToClipboard(input) {
		// Select input element content
		input.select();
		input.setSelectionRange(0, 99999); // For mobile devices

		// Copy the text
		document.execCommand("copy");
	}

	function showFailAlert(text) {
		showAlert(text, "Fail", 3000);
	}

	function showAlert(text, reason) {
		var messageBox = $("#alert" + reason);

		// Set message
		messageBox.children('span').first().text(text);

		// Show message
		messageBox.show();
	}

	/**
	 * Use window load event handler to initialize various things.
	 */
	window.addEventListener("load", function () {
		// Add button click event handlers
		btnGetLicenseReqStr = document.getElementById("btnGetLicenseReqStr");
		btnGetLicenseReqStr.addEventListener("click", btnGetLicensReqStr_click);
		btnUnregister = document.getElementById("btnUnregister");
		btnUnregister.addEventListener("click", btnUnregister_click);
		btnUnregisterOffline = document.getElementById("btnUnregisterOffline");
		btnUnregisterOffline.addEventListener("click", btnUnregisterOffline_click);
		btnRegister = document.getElementById("btnRegister");
		btnRegister.addEventListener("click", btnRegister_click);
		btnRenew = document.getElementById("btnRenew");
		btnRenew.addEventListener("click", btnRenew_click);
		btnRegMan = document.getElementById("btnRegMan");
		btnRegMan.addEventListener("click", btnRegMan_click);
		areaLicStrManual = document.getElementById("areaLicStrManual");
		areaLicStrManual.addEventListener("change", areaLicStrManual_change);
		areaLicStrManual.addEventListener("input", areaLicStrManual_change);

		var btnCopyLicReqStr = document.getElementById("btnCopyLicReqStr");
		var areaLicReqStr = document.getElementById("areaLicReqStr");
		btnCopyLicReqStr.addEventListener("click", function () { copyToClipboard(areaLicReqStr); });

		var btnCopyMachineId = document.getElementById("btnCopyMachineId");
		var txtLicenseMachineId = document.getElementById("txtLicenseMachineId");
		btnCopyMachineId.addEventListener("click", function () { copyToClipboard(txtLicenseMachineId); });
	});
})();
