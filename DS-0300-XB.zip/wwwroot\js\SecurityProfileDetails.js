﻿"use strict";

$(function () {
	$('input.uri-control').each(function () { validateURLElement($(this)); });

	// Add event handlers
	$('.btn-clipboard-copy').click(function () { copyToClipboard($(this).parent().prev('input').get(0)); });
	$('input.uri-control').change(function () { validateURLElement($(this)); });
	$('.btn-remove').click(function () { $(this).closest('.row').remove(); });
});

function addUriElement() {
	var uriId = ModelInfo.nextRedirectUriId++;

	var inputElement = $("<input></input>")
		.addClass("form-control uri-control is-invalid")
		.attr("type", "text")
		.attr("name", "ClientCredentials.AuthorizedRedirectUris[" + uriId + "]")
		.attr("spellcheck", false)
		.on("change", function () { validateURLElement(this) });

	var inlineFormElement = $("<div></div>")
		.addClass("input-group col-9")
		// Append element for edigint new uri.
		.append(inputElement)
		// Append input-group for removing this entry.
		.append($('<div class="input-group-append"></div>')
			.append($('<span class="btn btn-outline-secondary btn-remove"></div>')
				.click(function () { $(this).closest('.row').remove(); })
				.append($('<i class="tx-icon tx-icon-delete"></i>'))));

	var row = $('<div class="row"></div>')
		.append(inlineFormElement);

	// Add to DOM.
	$(".uri-listcontrol").append(row);

	// Set focus to added input element.
	inputElement.focus();
}

function copyToClipboard(copyText) {
	// Select the text field
	copyText.select();
	copyText.setSelectionRange(0, 99999); /*For mobile devices*/

	// Copy the text inside the text field
	document.execCommand("copy");
}

function validateURLElement(inputElement) {
	var jqInputElement = $(inputElement);
	if (validURL(jqInputElement.val())) {
		jqInputElement.removeClass("is-invalid");
	}
	else {
		jqInputElement.addClass("is-invalid");
	}

	// Validates whether the scheme of the passed string represents a URL.
	function validURL(str) {
		var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
			'((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
			'([a-z\\d]([a-z\\d-]*[a-z\\d])*)|' + // OR server name (TODO: check if this is correct)
			'((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
			'(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
			'(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
			'(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
		return pattern.test(str);
	}
}

function removeParentOf(event) {
	event.parentElement.remove();
}
