﻿(function () {
	"use strict";

	var btnUpdateAdminPassword;

	function setPasswordInputValidity(isValid) {
		setInputValidity(isValid, "txtNewPassword");
		setInputValidity(isValid, "txtConfirmNewPassword");
	}

	function setInputValidity(isValid, inputElementName) {
		var input = document.getElementById(inputElementName);
		if (isValid) {
			input.classList.remove("is-invalid");
		}
		else {
			input.classList.add("is-invalid");
		}
	}

	function showInvalidPasswordText(invalidText) {
		var invalidFeedback = document.getElementById("txtNewPassword_invalidFeedback");
		invalidFeedback.textContent = invalidText;
		setPasswordInputValidity(false);
	}

	/**
	 * Sends a http POST request to the Admin/UpdateAdminPassword controller.
	 * @param {string} newPassword - The new password.
	 */
	function sendUpdatePasswordRequest(newPassword) {
		var xhr = new XMLHttpRequest();
		xhr.addEventListener("load", transferComplete);
		xhr.addEventListener("error", function () {
			throw new Error("Password update request failed.");
		});
		xhr.open("POST", "users/admin/password");
		xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
		xhr.send(JSON.stringify({ newPassword: newPassword }));

		function transferComplete() {
			btnUpdateAdminPassword.disabled = false;
			switch (xhr.status) {
				case 200:
					setPasswordInputValidity(true);
					showAlert("alertPwdUpdateSuccess");
					break;

				case 400:
					showInvalidPasswordText(xhr.responseText);
					break;

				default:
					console.error("Password update request failed. Unexpected response code " + xhr.status + ".");
					break;
			}
		}
	}

	function showAlert(id) {
		$("#" + id).fadeTo(2000, 500).slideUp(500, function () {
			$("#" + id).slideUp(500);
		});					
	}

	/**
	 * "Update password" button event handler.
	 */
	function btnUpdateAdminPassword_click() {
		// Prevent multiple clicks
		btnUpdateAdminPassword.disabled = true;

		var txtNewPassword = document.getElementById("txtNewPassword");
		var txtConfirmNewPassword = document.getElementById("txtConfirmNewPassword");
		if (txtNewPassword.value !== txtConfirmNewPassword.value) {
			btnUpdateAdminPassword.disabled = false;
			showInvalidPasswordText("Passwords do not match.");
			return;
		}
		sendUpdatePasswordRequest(txtNewPassword.value);
	}

	/**
	 * Use window load event handler to initialize various things.
	 */
	window.addEventListener("load", function () {
		// Hide alerts
		$("#alertPwdUpdateSuccess").hide();

		// Add button click event handler
		btnUpdateAdminPassword = document.getElementById("btnUpdateAdminPassword");
		btnUpdateAdminPassword.addEventListener("click", btnUpdateAdminPassword_click);
	});
})();
