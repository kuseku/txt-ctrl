﻿# Changelog

All notable changes to this project will be documented in this file.

## [3.0.0] - 2022-09-12

### DS Server

#### Changed

- Upgrading from .NET Core 3.1 to .NET 6
- DSServer can be registered as a Windows service now.
- Adding hostsettings file (Port configuration in case DSServer is installed as a
  Windows Service).

### Document Editor

#### Fixed

- Improving FieldNavigator speed
- Formatting printer is not used when printing
- Font family and font size is changed when copying and pasting content through the clipboard
- Enabled property is missing for FormFields in JavaScript
- `SectionFormat.setColumnLineWidth()` lacks callback parameter
- `SectionFormat.getEqualColumnWidth()` and `SectionFormat.setEqualColumnWidth()` don't work
- Insert merge block button is active while a merge field is selected
- `FormattingStyle.setFontSize()` is defined twice
- `isSpellCheckingEnabled` cannot be set to true if no spell checker is available
- "Delete Field" button is still active after deleting merge field in the field navigation sidebar
- Multiple toggle buttons don't react to programmatical changes
- "changed" event doesn't work
- Text Field Created and Text Field Deleted events are missing in Javascript API
- Filling the merge field drop down menu could freeze the UI in case of complex data sources
- "Select all" button has visible effect now
- "Insert page break" button did not work correctly inside tables
- Commented text is not highlighted when navigating between comments
- `ApplicationField.getContainsInputPosition()` does not work
- Spell dialog not reflecting misspelled word after ignore

#### Added

- "Resource Kit" for localizing the application
- Form field events
- Getter and setter for property to enable and disable form field validation

### Document Viewer

#### Changed

- Show submenus below undocked toolbar instead at top of the viewer.
- Type of `SignatureSettings.SignatureBoxes` property changed to `ISignatureBoxCollection` interface.
- Type of `DocumentViewer.FrameBoxes` property changed to `IEnumerable<FrameBox>` interface.
- Embed signature's image as SVG instead as PNG in signed document.
- Use `<div>` instead of `<svg>` for visualizing the initials.
- Set opacity for border's of signature boxes.
- Optimize the page image rendering for text on browser-level. -> Improves the readness of text in Full-HD.
- `TXDocumentViewer.loadDocument` does not re-init the viewer anymore instead the content will be updated.
- `TXDocumentViewer.loadDocument` returns a promise because the loading of a document is processed asynchronously.

#### Fixed

- Show Progress Bar at top of the main-viewer if toolbar is undocked.
- Two page mode in full screen mode: document selection is possible
- SignatureBox.SignatureBoxStyle.Initials- initials are cut off in the signature box
- Signature-boxes are displaced after zooming
- Translations set through Resource property are not persistent
- Button for activating document selection is still active on activating annotation-editing
- Incorrect behaviour of the "Pan around" and "Document selection" buttons
- JS: `TXDocumentViewer.forms.showFormsBar` has no effect
- JS: Inconsistency between docu and behaviour of `TXDocumentViewer.toggleToolbar`

#### Added

- Feature: MVC and Javascript properties to set FormattingPrinter for DocumentViewer
- Feature: '`documentLoaded`' event for the `TXDocumentViewer.addEventListener` method
- Cosmetics: Visualize signatures as inactive and hide arrows
- Feature: Close button inside comments sidebar
- Feature: Hover hint for date form fields
- New property `MVC.DocumentViewer.Frameboxes`.
- New class `MVC.DocumentViewer.Framebox`.
- New property `MVC.DocumentViewer.SignatureSettings.SignatureBoxes`.
- New class `MVC.DocumentViewer.SignatureBox`.
- New class `MVC.DocumentViewer.SignatureBoxCollection`

### NuGet Packages

#### Changed

- Adding .NET 6.0 support
